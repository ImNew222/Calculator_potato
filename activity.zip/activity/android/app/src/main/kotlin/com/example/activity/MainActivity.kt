package com.example.activity

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
